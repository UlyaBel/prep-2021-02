#include "matrix.h"
#include <stdio.h>
#include <stdlib.h>

int get_cols(const Matrix* matrix) {
    int coll;
    coll = matrix->cols;
    printf("Количество столбцов: %d\n", coll);

    return coll;
}
