#include "matrix.h"
#include <stdio.h>
#include <stdlib.h>

Matrix* sub(const Matrix* l, const Matrix* r) {
    if ((l->rows == r->rows) && (l->cols == r->cols)) {
        for (size_t i = 0; i < l->rows; i++) {
            for (size_t j = 0; j < l->cols; j++) {
                 l->matrix[j][i] = l->matrix[j][i] - r->matrix[j][i];
            }
        } 
    } else {
        printf("Error of Sum");
    }

    printf("Полученная матрица при вычитании:\n");

    for (size_t i = 0; i < l->rows; i++) {
        for (size_t j = 0; j < l->cols; j++) {
            printf("%lf\t%s", l->matrix[j][i], (j == l->cols - 1) ? "\n" : "");
        }
    }

    return 0;
}
