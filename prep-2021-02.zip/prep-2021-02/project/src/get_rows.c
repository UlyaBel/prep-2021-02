#include "matrix.h"
#include <stdio.h>
#include <stdlib.h>

int get_rows(const Matrix *matrix) {
    int roww;
    roww = matrix->rows;
    printf("Количество строк: %d\n", roww);

    return roww;
}