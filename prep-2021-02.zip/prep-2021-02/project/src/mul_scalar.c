#include "matrix.h"
#include <stdio.h>
#include <stdlib.h>

Matrix* mul_scalar(const Matrix* matrix, double val) {
    for (size_t i = 0; i < matrix->rows; i++) {
        for (size_t j = 0; j < matrix->cols; j++) {
            matrix->matrix[j][i] = matrix->matrix[j][i] * val;
        }
    }

printf("Полученная матрица при умножении исходной матрицы на %lf:\n", val);
    for (size_t i = 0; i < matrix->rows; i++) {
        for (size_t j = 0; j < matrix->cols; j++) {
            printf("%lf\t%s", matrix->matrix[j][i], (j == matrix->cols - 1) ? "\n" : "");
        }
    }

    return (Matrix*)matrix;
}
