#include "matrix.h"
#include <stdio.h>
#include <stdlib.h>

Matrix* transp(const Matrix* matrix) {
    //float temp[matrix->rows][matrix->cols];
    //Matrix* matrix2;

    Matrix* temp_matr = create_matrix(matrix->cols, matrix->rows);

    //float temp;
    for (size_t i = 0; i < matrix->cols; i++) {
        for (size_t j = 0; j < matrix->rows; j++) {
            temp_matr->matrix[j][i] = matrix->matrix[i][j];

        }
    }

    printf("Полученная матрица при транспонировании:\n");
    for (size_t i = 0; i < matrix->cols; i++) {
        for (size_t j = 0; j < matrix->rows; j++) {
            printf("%lf\t%s", temp_matr->matrix[j][i], (j == matrix->rows - 1) ? "\n" : "");
        }
    }

    return 0; 
}