#include "matrix.h"
#include <stdio.h>
#include <stdlib.h>

//int get_elem(const Matrix* matrix, size_t row, size_t col, double* val) {
int get_elem(const Matrix* matrix, size_t row, size_t col) {
    //*val = matrix->matrix[row][col];
    printf("Значение элемента [%zu][%zu]: %lf\n", row, col, matrix->matrix[row][col]);

    return 0;
}