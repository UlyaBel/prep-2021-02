#include "matrix.h"
#include <stdio.h>
#include <stdlib.h>

Matrix* mul(const Matrix* l, const Matrix* r) {
    if (l->cols == r->rows) {
        Matrix* temp = create_matrix(l->rows, r->cols);
        for (size_t i = 0; i < l->rows; i++) {
            for (size_t j = 0; j < r->cols; j++) {
                temp->matrix[i][j] = 0;
                for (size_t k = 0; k < l->cols; k++) {
                    temp->matrix[i][j] += l->matrix[i][k] * r->matrix[k][j];
                }
                 // l->matrix[i][j] *= r->matrix[i][j];
            }
        } 
    printf("Полученная матрица при умножении 2-х матриц:\n");
    for (size_t i = 0; i < l->rows; i++) {
        for (size_t j = 0; j < r->cols; j++) {
            //printf("%lf\t%s", temp->matrix[j][i], (j == r->cols - 1) ? "\n" : "");
            printf("%lf\t%s", temp->matrix[j][i], (j == r->cols - 1) ? "\n" : "");
        }
    }

    } else {
        printf("Error of Mul");
    }

    

    return 0;
}
