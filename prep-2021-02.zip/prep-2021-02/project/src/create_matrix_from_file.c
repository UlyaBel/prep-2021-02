#include "matrix.h"
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
/*
Matrix* create_matrix_from_file(const char* path_file) {
    FILE *my_file;
    my_file = fopen(path_file, "r");
            if (my_file == NULL) {
                puts("Not acess");
            } else {
                int rows;
                int cols;
                float num[rows*cols];
                while (fscanf(my_file, "%d%d", &rows, &cols) != -1) {
                    printf("rows=%d  cols=%d\t\n", rows, cols);
                    Matrix* matr_fr_file = create_matrix(rows, cols);
                   // while (fscanf(my_file, "%f", *matr_fr_file->matrix) != -1) {
                    printf("Матрица, полученная из файла:\n");
                    while (fscanf(my_file, "%f", num) != -1) {
                        for (int j = 0; j < rows; j++) {
                            for (int i = 0; i < cols; i++) {
                                printf("%f\t", num[j*cols+i]);
                            }
                        }
                        //printf("%f\t", num[rows*cols]);
                        //for (int i = 0; i < cols; i++) {
                            //for (int j = 0; j < rows; j++) {
                                //printf("%f\t", matr_fr_file->matrix[j][i]);
                            //}
                        //}

                    for (int i = 0; i < rows; i++) {
                        for (int j = 0; j < cols; j++) {
                            printf("%f\t%s", num[i*cols+j], (j == cols - 1) ? "\n" : "");
                        }

                        
                    }
                    printf("\n");
                    fclose(my_file);
                    return matr_fr_file;
                }

    }
                }
    return 0;
}
*/


// Создание матрицы из файла
Matrix* create_matrix_from_file(const char* path_file) {
    FILE *file;
    file = fopen(path_file, "r");
    if (file == NULL) {
        puts("Not access");
        return NULL;
    } else {
        size_t rows = 0;
        size_t cols = 0;
        fscanf(file, "%zu%zu", &rows, &cols);
        //printf("rows = %zu\tcols = %zu\n", rows, cols);
        Matrix* new_matr = create_matrix(rows, cols);
        //fscanf(file, "%d%d", &(new_matr->rows), &(new_matr->cols));
        new_matr->rows = rows;
        new_matr->cols = cols;
        for (size_t j = 0; j < rows; j++) {
            for (size_t i = 0; i < cols; i++) {
                fscanf(file, "%lf", &(new_matr->matrix)[i][j]);
            }
        }
        /*printf("Матрица, полученная из файла:\n");
        for (size_t j = 0; j < rows; j++) {
            for (size_t i = 0; i < cols; i++) {
                printf("%f\t%s", (new_matr->matrix)[i][j], (i == cols - 1) ? "\n" : "");
            }
        }*/
        fclose(file);
        return new_matr;
    }
    return NULL;
}