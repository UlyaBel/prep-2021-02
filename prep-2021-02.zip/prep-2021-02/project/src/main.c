#include <stdio.h>
#include <stdlib.h>
#include "matrix.h"

/*
#define Test_1 1
#define Test_2 2
#define Test_3 3
*/
int main(void) {
/*int Test_case = 2;
switch (Test_case) {
    case (Test_1):
    */
        /*Matrix* matrica = NULL;
        matrica = create_matrix(9, 7);
        free_matrix(matrica);*/
        //break;
    //case (Test_2):
       /* const char* path_file = "file_with_matrix.dat";
        Matrix* matrica2 = NULL;
        matrica2 = create_matrix_from_file(path_file);
        printf("matrica2->rows=%d", matrica2->rows);
        //break;
//}
        get_rows(matrica2, rows);*/
        const char* path_file = "file_with_matrix.dat";
        Matrix* matr = create_matrix_from_file(path_file);
        printf("rows = %zu\tcols = %zu\n", matr->rows, matr->cols);
        printf("Полученная из файла матрица:\n");
        for (size_t j = 0; j < matr->rows; j++) {
            for (size_t i = 0; i < matr->cols; i++) {
                printf("%f\t%s", (matr->matrix)[i][j], (i == matr->cols - 1) ? "\n" : "");
            }
        }

        //size_t *row1;
        //row1 = &(matr->rows);
        get_rows(matr);
        get_cols(matr);

        
        //get_elem(matr, 0, 1, val);
        get_elem(matr, 0, 1);

        /*double value;
        printf("Введите значение в матрице, которое хотите заменить:\n");
        scanf("%lf", &value);*/
        set_elem(matr, 0, 1, -1.2);
        
        double test = 2;
        double* value;
        value = &test;

        mul_scalar(matr, *value);

        //transp(matr);
        const char* path_file_0 = "file_with_matrix.dat";
        Matrix* matr_0 = create_matrix_from_file(path_file_0);

        /*const char* path_file_2 = "file_with_matrix_2.dat";
        Matrix* matr_2 = create_matrix_from_file(path_file_2);

        const char* path_file_3 = "file_with_matrix_3.dat";
        Matrix* matr_3 = create_matrix_from_file(path_file_3);*/

        const char* path_file_4 = "file_with_matrix_4.dat";
        Matrix* matr_4 = create_matrix_from_file(path_file_4);

        mul(matr_0, matr_4);

        //sub(matr_0, matr_2);
        //sum(matr_0, matr_2);
        const char* path_file_5 = "file_with_matrix_5.dat";
        Matrix* matr_5 = create_matrix_from_file(path_file_5);
        double* val = 0;
        det(matr_5, val);

        free_matrix(matr);
return 0;
}
