#ifndef _MATRIX_H_
#define _MATRIX_H_

#include <stddef.h>
#include <stdlib.h>

typedef struct Matrix {
    size_t rows;
    size_t cols;
    double** matrix;
} Matrix;

// Init/release operations
Matrix* create_matrix_from_file(const char* path_file);  // создание матрицы из файла. Принимает путь к 
                                                         // файлу с матрицей. Формат представления матрицы в файле
                                                         // creating a matrix from a file. Accepts the path to the matrix file. 
                                                         // Format of matrix representation in a file
Matrix* create_matrix(size_t rows, size_t cols);  // create an empty matrix size <rows>*<cols>
void free_matrix(Matrix* matrix);  // release the resources occupied by the matrix (освободить ресурсы, занимаемые матрицей)

// Basic operations
//int get_rows(const Matrix* matrix, size_t* rows);  // get the number of rows (строк)
int get_rows(const Matrix* matrix);
int get_cols(const Matrix* matrix);  // get the number of columns (столбцов)
//int get_elem(const Matrix* matrix, size_t row, size_t col, double* val);  // get the value of an element at a position [<row>, <col>]
int get_elem(const Matrix* matrix, size_t row, size_t col);
int set_elem(Matrix* matrix, size_t row, size_t col, double val);  // set the val value of the element at the position [<row>, <col>]

//Math operations
Matrix* mul_scalar(const Matrix* matrix, double val);  // scalar matrix multiplication by a real value
Matrix* transp(const Matrix* matrix);  // matrix transposition

Matrix* sum(const Matrix* l, const Matrix* r);  // matrix addition
Matrix* sub(const Matrix* l, const Matrix* r);  // matrix subtraction
Matrix* mul(const Matrix* l, const Matrix* r);  // matrix multiplication

// Extra operations
int det(const Matrix* matrix, double* val);  // matrix determinant
Matrix* adj(const Matrix* matrix);  // присоединенная (сопряженная) матрица // adjoint matrix
Matrix* inv(const Matrix* matrix);  // inverse matrix

#endif //_MATRIX_H_
