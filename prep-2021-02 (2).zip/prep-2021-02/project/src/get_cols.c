#include "matrix.h"
#include <stdio.h>
#include <stdlib.h>

int get_cols(const Matrix* matrix, size_t* cols) {
    if (matrix != NULL) {
        *cols = (*matrix).cols;
        printf("Количество столбцов: %zu\n", *cols);
        return 0;
    } else {
        return 1;
    }
}
