#include "matrix.h"
#include <stdio.h>
#include <stdlib.h>

int get_rows(const Matrix* matrix, size_t* rows) {
    if (matrix != NULL) {
        *rows = (*matrix).rows;
        printf("Количество строк: %zu\n", *rows);
        return 0;
    }
    return 1;
}
