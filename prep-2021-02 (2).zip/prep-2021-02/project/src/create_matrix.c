#include "matrix.h"
#include <malloc.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

Matrix* create_matrix(size_t rows, size_t cols) {
    Matrix* p_matr = {0};
    p_matr = malloc(sizeof(Matrix));
    p_matr->matrix = malloc(sizeof(* (p_matr->matrix)) * cols);
    for (size_t j = 0; j < cols; j++) {
        (p_matr->matrix)[j] = malloc(sizeof(** (p_matr->matrix)) * rows);
    }
    /* for (size_t i = 0; i < rows; i++) {
        for (size_t j = 0; j < cols; j++) {
            (p_matr->matrix)[j][i] = (10*i) + j;
        }
    }
    
    for (size_t i = 0; i < rows; i++) {
        for (size_t j = 0; j < cols; j++) {
            printf("%f\t%s", (p_matr->matrix)[j][i], (j == cols - 1) ? "\n" : "");
        }
    }  */
    // printf("DONE");
    return p_matr;
}
