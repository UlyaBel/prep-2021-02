#include "matrix.h"
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>

// Создание матрицы из файла
Matrix* create_matrix_from_file(const char* path_file) {
    FILE *file;
    file = fopen(path_file, "r");
    if (file == NULL) {
        puts("Not access");
        return NULL;
    } else {
        size_t rows = 0;
        size_t cols = 0;
        fscanf(file, "%zu%zu", &rows, &cols);
        // printf("rows = %zu\tcols = %zu\n", rows, cols);
        Matrix* new_matr = create_matrix(rows, cols);
        // fscanf(file, "%d%d", &(new_matr->rows), &(new_matr->cols));
        new_matr->rows = rows;
        new_matr->cols = cols;
        for (size_t j = 0; j < rows; j++) {
            for (size_t i = 0; i < cols; i++) {
                fscanf(file, "%lf", &(new_matr->matrix)[i][j]);
            }
        }
        /* printf("Матрица, полученная из файла:\n");
        for (size_t j = 0; j < rows; j++) {
            for (size_t i = 0; i < cols; i++) {
                printf("%f\t%s", (new_matr->matrix)[i][j], (i == cols - 1) ? "\n" : "");
            }
        }  */
        fclose(file);
        return new_matr;
    }
    return NULL;
}
