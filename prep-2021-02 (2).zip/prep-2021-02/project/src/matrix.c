#include "matrix.h"
#include <malloc.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

// Создание матрицы из файла
Matrix* create_matrix_from_file(const char* path_file) {
    FILE *file;
    file = fopen(path_file, "r");
    if (file == NULL) {
        puts("Not access");
        return NULL;
    } else {
        size_t rows = 0;
        size_t cols = 0;
        fscanf(file, "%zu%zu", &rows, &cols);
        // printf("rows = %zu\tcols = %zu\n", rows, cols);
        Matrix* new_matr = create_matrix(rows, cols);
        // fscanf(file, "%d%d", &(new_matr->rows), &(new_matr->cols));
        new_matr->rows = rows;
        new_matr->cols = cols;
        for (size_t j = 0; j < rows; j++) {
            for (size_t i = 0; i < cols; i++) {
                fscanf(file, "%lf", &(new_matr->matrix)[i][j]);
            }
        }
        printf("Матрица, полученная из файла:\n");
        for (size_t j = 0; j < rows; j++) {
            for (size_t i = 0; i < cols; i++) {
                printf("%f\t%s", (new_matr->matrix)[i][j], (i == cols - 1) ? "\n" : "");
            }
        }
        fclose(file);
        return new_matr;
    }
    return NULL;
}

Matrix* create_matrix(size_t rows, size_t cols) {
    Matrix* p_matr = {0};
    p_matr = malloc(sizeof(Matrix));
    p_matr->matrix = malloc(sizeof(* (p_matr->matrix)) * cols);
    for (size_t j = 0; j < cols; j++) {
        (p_matr->matrix)[j] = malloc(sizeof(** (p_matr->matrix)) * rows);
    }
    return p_matr;
}

void free_matrix(Matrix* matrix) {
    for (size_t i = 0; i < (*matrix).cols; i++) {
        free(*(matrix->matrix+i));
    }
    matrix->matrix = NULL;
    free(matrix);
}

int get_rows(const Matrix* matrix, size_t* rows) {
    if (matrix != NULL) {
        *rows = (*matrix).rows;
        printf("Количество строк: %zu\n", *rows);
        return 0;
    }
    return 1;
}

int get_cols(const Matrix* matrix, size_t* cols) {
    if (matrix != NULL) {
        *cols = (*matrix).cols;
        printf("Количество столбцов: %zu\n", *cols);
        return 0;
    } else {
        return 1;
    }
}

int get_elem(const Matrix* matrix, size_t row, size_t col, double* val) {
    if (matrix != NULL) {
        *val = (*matrix).matrix[col-1][row-1];
        printf("Значение элемента [%zu][%zu]: %lf\n", row, col, matrix->matrix[row][col]);
        return 0;
    } else {
        return 1;
    }
}

int set_elem(Matrix* matrix, size_t row, size_t col, double val) {
    if (matrix != NULL) {
        matrix->matrix[row][col] = val;
        printf("Значение заменённого элемента [%zu][%zu]: %lf\n", row, col, val);

        printf("Полученная матрица:\n");
        for (size_t i = 0; i < matrix->rows; i++) {
            for (size_t j = 0; j < matrix->cols; j++) {
                printf("%lf\t%s", matrix->matrix[j][i], (j == matrix->cols - 1) ? "\n" : "");
            }
        }
        return 0;
    }
    return 1;
}

Matrix* mul_scalar(const Matrix* matrix, double val) {
    if (matrix != NULL) {
        for (size_t i = 0; i < matrix->rows; i++) {
            for (size_t j = 0; j < matrix->cols; j++) {
                matrix->matrix[j][i] = matrix->matrix[j][i] * val;
            }
        }
        printf("Полученная матрица при умножении исходной матрицы на %lf:\n", val);
        for (size_t i = 0; i < matrix->rows; i++) {
            for (size_t j = 0; j < matrix->cols; j++) {
                printf("%lf\t%s", matrix->matrix[j][i], (j == matrix->cols - 1) ? "\n" : "");
            }
        }
        return (Matrix*)matrix;
    }
    return NULL;
}

Matrix* transp(const Matrix* matrix) {
    if (matrix != NULL) {
        Matrix* temp_matr = create_matrix(matrix->cols, matrix->rows);
        for (size_t i = 0; i < matrix->cols; i++) {
            for (size_t j = 0; j < matrix->rows; j++) {
                temp_matr->matrix[j][i] = matrix->matrix[i][j];
            }
        }
        printf("Полученная матрица при транспонировании:\n");
        for (size_t i = 0; i < matrix->cols; i++) {
            for (size_t j = 0; j < matrix->rows; j++) {
                 printf("%lf\t%s", temp_matr->matrix[j][i], (j == matrix->rows - 1) ? "\n" : "");
            }
        }
        return temp_matr;
    }
    return NULL;
}

Matrix* sum(const Matrix* l, const Matrix* r) {
    if (l == NULL) {
        return NULL;
    }
    if (r == NULL) {
        return NULL;
    }
    if ((l->rows == r->rows) && (l->cols == r->cols)) {
        for (size_t i = 0; i < l->rows; i++) {
            for (size_t j = 0; j < l->cols; j++) {
                l->matrix[j][i] = l->matrix[j][i] + r->matrix[j][i];
            }
        }

        printf("Полученная матрица при сложении:\n");
        for (size_t i = 0; i <l->rows; i++) {
            for (size_t j = 0; j < l->cols; j++) {
                printf("%lf\t%s", l->matrix[j][i], (j == l->cols - 1) ? "\n" : "");
            }
        }
        return (Matrix*)l;
    }
    return NULL;
}

Matrix* sub(const Matrix* l, const Matrix* r) {
    if (l == NULL) {
        printf("Error of Sum");
        return NULL;
    }
    if (r == NULL) {
        printf("Error of Sum");
        return NULL;
    }
    if ((l->rows == r->rows) && (l->cols == r->cols)) {
        for (size_t i = 0; i < l->rows; i++) {
            for (size_t j = 0; j < l->cols; j++) {
                l->matrix[j][i] = l->matrix[j][i] - r->matrix[j][i];
            }
        }
        printf("Полученная матрица при вычитании:\n");
        for (size_t i = 0; i < l->rows; i++) {
            for (size_t j = 0; j < l->cols; j++) {
                printf("%lf\t%s", l->matrix[j][i], (j == l->cols - 1) ? "\n" : "");
            }
        }
        return (Matrix*)l;
    }
    return NULL;
}

Matrix* mul(const Matrix* l, const Matrix* r) {
    if (l == NULL) {
        return NULL;
    }
    if (r == NULL) {
        return NULL;
    }
    if (l->cols == r->rows) {
        Matrix* temp = create_matrix(l->rows, r->cols);
        for (size_t i = 0; i < l->rows; i++) {
            for (size_t j = 0; j < r->cols; j++) {
                temp->matrix[j][i] = 0;
                for (size_t k = 0; k < l->cols; k++) {
                    temp->matrix[j][i] += l->matrix[k][i] * r->matrix[j][k];
                }
            }
        }
        printf("Полученная матрица при умножении 2-х матриц:\n");
        for (size_t i = 0; i < l->rows; i++) {
            for (size_t j = 0; j < r->cols; j++) {
                printf("%lf\t%s", temp->matrix[j][i], (j == r->cols - 1) ? "\n" : "");
            }
        }
        return temp;
    }
    return NULL;
}
