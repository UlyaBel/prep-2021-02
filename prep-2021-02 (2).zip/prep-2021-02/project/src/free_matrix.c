#include "matrix.h"
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>

void free_matrix(Matrix* matrix) {
    for (size_t i = 0; i < (*matrix).cols; i++) {
        free(*(matrix->matrix+i));
    }
    matrix->matrix = NULL;
    free(matrix);
}
