#include "matrix.h"
#include <stdio.h>
#include <stdlib.h>

Matrix* mul(const Matrix* l, const Matrix* r) {
    if (l == NULL) {
        return NULL;
    }
    if (r == NULL) {
        return NULL;
    }
    if (l->cols == r->rows) {
        Matrix* temp = create_matrix(l->rows, r->cols);
        for (size_t i = 0; i < l->rows; i++) {
            for (size_t j = 0; j < r->cols; j++) {
                temp->matrix[j][i] = 0;
                for (size_t k = 0; k < l->cols; k++) {
                    temp->matrix[j][i] += l->matrix[k][i] * r->matrix[j][k];
                }
            }
        }
        printf("Полученная матрица при умножении 2-х матриц:\n");
        for (size_t i = 0; i < l->rows; i++) {
            for (size_t j = 0; j < r->cols; j++) {
                printf("%lf\t%s", temp->matrix[j][i], (j == r->cols - 1) ? "\n" : "");
            }
        }
        return temp;
    }
    return NULL;
}
