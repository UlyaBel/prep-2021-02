#include "matrix.h"
#include <stdio.h>
#include <stdlib.h>

int get_elem(const Matrix* matrix, size_t row, size_t col, double* val) {
    if (matrix != NULL) {
        *val = (*matrix).matrix[col-1][row-1];
        printf("Значение элемента [%zu][%zu]: %lf\n", row, col, matrix->matrix[row][col]);
        return 0;
    } else {
        return 1;
    }
}
