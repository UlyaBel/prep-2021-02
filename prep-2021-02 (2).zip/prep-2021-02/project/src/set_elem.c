#include "matrix.h"
#include <stdio.h>
#include <stdlib.h>

int set_elem(Matrix* matrix, size_t row, size_t col, double val) {
    if (matrix != NULL) {
        matrix->matrix[row][col] = val;
        printf("Значение заменённого элемента [%zu][%zu]: %lf\n", row, col, val);

        printf("Полученная матрица:\n");
        for (size_t i = 0; i < matrix->rows; i++) {
            for (size_t j = 0; j < matrix->cols; j++) {
                printf("%lf\t%s", matrix->matrix[j][i], (j == matrix->cols - 1) ? "\n" : "");
            }
        }
        return 0;
    }
    return 1;
}
